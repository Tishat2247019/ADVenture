function ad_based_catecogry(event, ad_category_value, search_word) {
  //   ad_category_value = document.getElementById("ad_category").value;
  //   alert(document.getElementById("ad_category").value);

  event.preventDefault();
  let xhttp = new XMLHttpRequest();
  xhttp.open("POST", "../../../controller/manage_ad_server.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  if (ad_category_value == null) {
    xhttp.send("id=" + idd + "&search_word=" + search_word);
  } else {
    xhttp.send("id=" + idd + "&ad_category=" + ad_category_value);
  }
  xhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
      let tableBody = document.querySelector(".ad_table tbody");

      if (!tableBody) {
        tableBody = document.createElement("tbody");
        document.querySelector(".ad_table").appendChild(tableBody);
      }

      if (this.responseText === "no add found") {
        // Create a new <tr> and <td> to display the message
        let messageRow = document.createElement("tr");
        let messageCell = document.createElement("td");
        messageCell.setAttribute("colspan", "8"); // Makes the message span across all columns

        messageCell.innerHTML = "No Ads Found"; // Style it with large font and center text

        messageCell.style.cssText =
          "text-align :center; height : 300px; font-size:100px; font-weight:bold; color:red"; // Append the row with the message
        messageRow.appendChild(messageCell);
        tableBody.innerHTML = ""; // Clear existing content
        tableBody.appendChild(messageRow);
      } else {
        // If not "no ads found", populate the table with the response text
        tableBody.innerHTML = this.responseText;
      }
    }
  };
}

window.onload = function () {
  ad_based_catecogry(event, "All", null);
};

let adId = null;

function confirmDelete(adId1) {
  // Show confirmation dialog

  const popup = document.getElementById("confirmPopup");
  const message = document.getElementById("popupMessage");

  message.innerText = `Are you sure you want to delete user ${adId1}?`;
  popup.style.display = "block";

  document.getElementById("confirmYes").style.display = "inline-block";
  document.getElementById("confirmNo").style.display = "inline-block";
  document.getElementById("confirmOk").style.display = "none";

  adId = adId1;
}

function confirmDelete1(event) {
  event.preventDefault();
  const popup = document.getElementById("confirmPopup");
  const message = document.getElementById("popupMessage");
  let xhttp = new XMLHttpRequest();
  xhttp.open("POST", "../../../model/delete_ad.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("idt=" + adId);

  xhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
      const response = JSON.parse(xhttp.responseText);
      if (response.success === true) {
        // alert("User deleted successfully");
        message.innerText = `Ad ${adId} successfully deleted.`;
        document.getElementById("confirmYes").style.display = "none";
        document.getElementById("confirmNo").style.display = "none";
        document.getElementById("confirmOk").style.display = "block";
      } else {
        // alert(response.message);
        message.innerText = `Error: ${response.message}`;
      }
    }
  };
}

document.getElementById("confirmNo").addEventListener("click", function () {
  const popup = document.getElementById("confirmPopup");
  popup.style.display = "none"; // Hide the popup
});

document.getElementById("confirmOk").addEventListener("click", function () {
  const ok = document.getElementById("confirmPopup");
  ok.style.display = "none"; // Hide the popup
});
