let ad_id = null;

function confirmedit(event, ad_id1) {
  event.preventDefault();
  const popup = document.getElementById("confirmPopup");
  const message = document.getElementById("popupMessage");

  message.innerText = `Are you sure you want to edit information of  ad ${ad_id1}?`;
  popup.style.display = "block";

  document.getElementById("confirmYes").style.display = "inline-block";
  document.getElementById("confirmNo").style.display = "inline-block";
  document.getElementById("confirmOk").style.display = "none";

  ad_id = ad_id1;
}

function confirmedit1(event) {
  event.preventDefault();
  // console.log(document.getElementById("new_category").value);
  const message = document.getElementById("popupMessage");

  let new_ad_title = document.getElementById("new_ad_title").value;
  let new_ad_description = document.getElementById("new_ad_description").value;
  let new_phone = document.getElementById("new_phone").value;
  let new_email = document.getElementById("new_email").value;
  let new_price = document.getElementById("new_price").value;
  let new_category = document.getElementById("new_category").value;

  let xhttp = new XMLHttpRequest();
  xhttp.open("POST", "../../../controller/edit_ad_server.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(
    "idt=" +
      ad_id +
      "&new_ad_title=" +
      new_ad_title +
      "&new_ad_description=" +
      new_ad_description +
      "&new_phone=" +
      new_phone +
      "&new_email=" +
      new_email +
      "&new_price=" +
      new_price +
      "&new_category=" +
      new_category
  );

  xhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
      message.innerHTML = this.responseText;
      document.getElementById("confirmYes").style.display = "none";
      document.getElementById("confirmNo").style.display = "none";
      document.getElementById("confirmOk").style.display = "block";
      // alert(this.responseText);
    }
  };
}

document.getElementById("confirmNo").addEventListener("click", function () {
  const popup = document.getElementById("confirmPopup");
  popup.style.display = "none";
});

document.getElementById("confirmOk").addEventListener("click", function () {
  const ok = document.getElementById("confirmPopup");
  ok.style.display = "none";
});
