<?php
require_once("../../../model/usermodel.php");
$idd = $_REQUEST['id'];
$row = user_info($idd);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Profile Photo</title>
    <link rel="stylesheet" href="../../../asset/css/opi_css_files/cng_profile_pic.css">
</head>
<body>
    <div class="container">
        <div class="icon">
            <img src="../../../asset/images/opi_images/features_pics/profile-pic.png" alt="">
        </div>
        <h1>Change Profile Photo</h1>
        <form class="change-photo-form" action="../../../controller/opi_controller/cng_profile_pic_check.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="current-photo">Current Profile Photo</label>
                <img id="current-photo" src="../../../asset/images/profile_pics/<?php echo $row['profile_pic']?>" alt="">
            </div>
            <div class="form-group">
                <label for="new-photo">Upload New Profile Photo</label>
                <input type="file" id="new-photo" name="new_photo" accept="image/*" >
                <input type="hidden" name="user_id" value="<?php echo $idd ?>">
            </div>
            <button type="submit" class="save-button" >Save Changes</button>
            <section align="center" class="backbutton">
            <a href="../menu/user_menu.php?id=<?php echo $idd; ?>">Go Back</a>

        </section>
        </form>
    </div>


    <footer>
        <div class="footer-container" align="center">
            <div class="footer-section">
                <h4>More from Us</h4>
                <ul>
                    <li><a href="">Our Portfolio</a></li>
                    <li><a href="">Success Stories</a></li>
                    <li><a href="">Partners & Affiliates</a></li>
                    <li><a href="">Subscribe for Updates</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Help & Support</h4>
                <ul>
                    <li><a href="">FAQs</a></li>
                    <li><a href="">Stay Safe</a></li>
                    <li><a href="">Contact Us</a></li>
                    <li><a href="">Report an Issue</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>About ADVenture</h4>
                <ul>
                    <li><a href="">About Us</a></li>
                    <li><a href="">Meet the Team</a></li>
                    <li><a href="">Careers</a></li>
                    <li><a href="">Terms and Conditions</a></li>
                    <li><a href="">Privacy policy</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Guidelines</h4>
                <ul>
                    <li><a href="">Getting Started</a></li>
                    <li><a href="">Best Practices</a></li>
                    <li><a href="">Do's and Don'ts</a></li>
                </ul>
                <div class="social-icons">
                    <a href="https://www.facebook.com/"><img src="../../../asset/images/opi_images/features_pics/fb-icon.png"
                            alt="Facebook"></a>
                    <a href="https://x.com/?lang=en"><img src="../../../asset/images/opi_images/features_pics/x-icon.png"
                            alt="Twitter"></a>
                    <a href="https://www.tiktok.com/login"><img src="../../../asset/images/opi_images/features_pics/tiktok-icon.png"
                            alt="TikTok"></a>
                    <a href="https://www.youtube.com/"><img src="../../../asset/images/opi_images/features_pics/youtube-icon.png"
                            alt="YouTube"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025. All rights reserved. ADVenture</p>
        </div>
    </footer>


    <script src="../../../asset/js/opi_js/cng_profile_pic.js"></script>
</body>
</html>